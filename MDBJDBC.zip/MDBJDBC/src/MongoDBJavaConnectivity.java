import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import org.bson.Document;

import java.util.Scanner;

public class MongoDBJavaConnectivity {
    private static MongoCollection<Document> collection;

    public static void main(String[] args) {
        try (MongoClient mongoClient = MongoClients.create("mongodb://localhost:27017")) {
            MongoDatabase database = mongoClient.getDatabase("testdb");
            collection = database.getCollection("testCollection");

            Scanner scanner = new Scanner(System.in);
            boolean exit = false;

            while (!exit) {
                System.out.println("Choose an operation: ");
                System.out.println("1. Add Document");
                System.out.println("2. View Documents");
                System.out.println("3. Update Document");
                System.out.println("4. Delete Document");
                System.out.println("5. Exit");
                int choice = scanner.nextInt();
                scanner.nextLine(); // Consume newline

                switch (choice) {
                    case 1 -> addDocument(scanner);
                    case 2 -> viewDocuments();
                    case 3 -> updateDocument(scanner);
                    case 4 -> deleteDocument(scanner);
                    case 5 -> exit = true;
                    default -> System.out.println("Invalid choice! Please try again.");
                }
            }
        }
    }

    private static void addDocument(Scanner scanner) {
        System.out.print("Enter name: ");
        String name = scanner.nextLine();
        System.out.print("Enter age: ");
        int age = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        Document document = new Document("name", name)
                .append("age", age);
        collection.insertOne(document);
        System.out.println("Document added successfully.");
    }

    private static void viewDocuments() {
        for (Document doc : collection.find()) {
            System.out.println(doc.toJson());
        }
    }

    private static void updateDocument(Scanner scanner) {
        System.out.print("Enter name of the document to update: ");
        String name = scanner.nextLine();
        System.out.print("Enter new age: ");
        int newAge = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        collection.updateOne(Filters.eq("name", name), new Document("$set", new Document("age", newAge)));
        System.out.println("Document updated successfully.");
    }

    private static void deleteDocument(Scanner scanner) {
        System.out.print("Enter name of the document to delete: ");
        String name = scanner.nextLine();

        collection.deleteOne(Filters.eq("name", name));
        System.out.println("Document deleted successfully.");
    }
}