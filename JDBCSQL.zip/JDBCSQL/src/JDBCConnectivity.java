import java.io.FileInputStream;
import java.io.IOException;
import java.sql.*;
import java.util.Properties;
import java.util.Scanner;

public class JDBCConnectivity {

    public static void main(String[] args) {
        Connection db = null;
        Scanner sc = new Scanner(System.in);

        // Load database properties
        Properties props = new Properties();
        try (FileInputStream fis = new FileInputStream("./src/.env")) {
            props.load(fis);
        } catch (IOException e) {
            System.err.println("Error loading properties file.");
            e.printStackTrace();
            return;
        }

        String dbUrl = props.getProperty("db.url");
        String dbUser = props.getProperty("db.user");
        String dbPassword = props.getProperty("db.password");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            db = DriverManager.getConnection(dbUrl, dbUser, dbPassword);
            if (db != null) {
                System.out.println("Connected to Database Successfully");

                int choice;
                do {
                    System.out.println("\nMenu:");
                    System.out.println("1. Show Table");
                    System.out.println("2. Insert New Record");
                    System.out.println("3. Update Record");
                    System.out.println("4. Delete Record");
                    System.out.println("5. Exit");
                    System.out.print("Enter your choice: ");
                    choice = sc.nextInt();
                    sc.nextLine();  // Consume newline

                    switch (choice) {
                        case 1:
                            readFields(db);
                            break;
                        case 2:
                            insertFields(sc, db);
                            break;
                        case 3:
                            updateFields(sc, db);
                            break;
                        case 4:
                            deleteFields(sc, db);
                            break;
                        case 5:
                            System.out.println("Exiting...");
                            break;
                        default:
                            System.out.println("Invalid choice. Please try again.");
                    }
                } while (choice != 5);
            }
        } catch (SQLException e) {
            System.err.println("SQL error occurred.");
            e.printStackTrace();
        } catch (Exception e) {
            System.err.println("An unexpected error occurred.");
            e.printStackTrace();
        } finally {
            try {
                if (db != null) db.close();
                sc.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    // Insert function
    private static void insertFields(Scanner sc, Connection db) throws SQLException {
        System.out.print("Enter the name: ");
        String name = sc.nextLine();
        System.out.print("Enter the age: ");
        int age = sc.nextInt();
        sc.nextLine();
        System.out.print("Enter gender: ");
        String gender = sc.nextLine();

        String query = "INSERT INTO john_wick_characters (name, age, gender) VALUES (?, ?, ?)";
        PreparedStatement preparedStatement = db.prepareStatement(query);
        preparedStatement.setString(1, name);
        preparedStatement.setInt(2, age);
        preparedStatement.setString(3, gender);

        int rows = preparedStatement.executeUpdate();
        if (rows > 0) {
            System.out.println(rows + " row(s) inserted.");
        }
    }

    // Read function
    private static void readFields(Connection db) throws SQLException {
        String query = "SELECT * FROM john_wick_characters";
        PreparedStatement preparedStatement = db.prepareStatement(query);
        ResultSet resultSet = preparedStatement.executeQuery();

        System.out.println("ID | Name | Age | Gender");
        while (resultSet.next()) {
            System.out.println(resultSet.getInt("character_id") + " | " +
                    resultSet.getString("name") + " | " +
                    resultSet.getInt("age") + " | " +
                    resultSet.getString("gender"));
        }
    }

    // Update function
    private static void updateFields(Scanner sc, Connection db) throws SQLException {
        System.out.print("Enter the character ID to update: ");
        int character_id = sc.nextInt();
        sc.nextLine();  // Consume newline

        System.out.print("Enter new name: ");
        String name = sc.nextLine();
        System.out.print("Enter new age: ");
        int age = sc.nextInt();
        sc.nextLine();  // Consume newline
        System.out.print("Enter new gender: ");
        String gender = sc.nextLine();

        String query = "UPDATE john_wick_characters SET name = ?, age = ?, gender = ? WHERE character_id = ?";
        PreparedStatement preparedStatement = db.prepareStatement(query);
        preparedStatement.setString(1, name);
        preparedStatement.setInt(2, age);
        preparedStatement.setString(3, gender);
        preparedStatement.setInt(4, character_id);

        int rows = preparedStatement.executeUpdate();
        if (rows > 0) {
            System.out.println(rows + " row(s) updated.");
        } else {
            System.out.println("No record found with that ID.");
        }
    }

    // Delete function
    private static void deleteFields(Scanner sc, Connection db) throws SQLException {
        System.out.print("Enter the character ID to delete: ");
        int character_id = sc.nextInt();
        sc.nextLine();  // Consume newline

        String query = "DELETE FROM john_wick_characters WHERE character_id = ?";
        PreparedStatement preparedStatement = db.prepareStatement(query);
        preparedStatement.setInt(1, character_id);

        int rows = preparedStatement.executeUpdate();
        if (rows > 0) {
            System.out.println(rows + " row(s) deleted.");
        } else {
            System.out.println("No record found with that ID.");
        }
    }
}